# GCrawler

A crawler framework use gevent.

## Intro

1. small and lightweight
1. use gevent

## Deploy

1. require gevent
